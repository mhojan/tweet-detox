
import json
import os
import time
import requests
import http.client
from datetime import datetime
from dotenv import load_dotenv
from requests_oauthlib import OAuth1

# Load your API keys securely from a file named .env
# Make sure your .env file has: API_KEY, API_SECRET, ACCESS_TOKEN, ACCESS_SECRET
load_dotenv()
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
ACCESS_SECRET = os.getenv("ACCESS_SECRET")

# X/Twitter's v1.1 endpoint to delete a tweet by its ID.
DELETE_URL = "https://api.twitter.com/1.1/statuses/destroy/{}.json"

if not all([API_KEY, API_SECRET, ACCESS_TOKEN, ACCESS_SECRET]):
    raise ValueError("❌ One or more API credentials are missing. Check your .env file.")

# Authenticate using OAuth1 (needed to make requests on your behalf)
auth = OAuth1(API_KEY, API_SECRET, ACCESS_TOKEN, ACCESS_SECRET)

# Optional: Set the date range for tweets you want to delete
# Use the format: YYYY, M, D (Year, Month, Day)
# If you leave one as None, it will just use the other limit
MIN_DATE = datetime(2024, 6, 8)
MAX_DATE = datetime(2024, 6, 9)

# If either is None, replace with extreme bounds
# If both are None, it will delete all your tweets
if not MIN_DATE:
    MIN_DATE = datetime.min
if not MAX_DATE:
    MAX_DATE = datetime.max

# Load already deleted tweet IDs so we don't try deleting them again
deleted_ids_path = "deleted_ids.txt"
if os.path.exists(deleted_ids_path):
    with open(deleted_ids_path, "r") as f:
        deleted_ids = set(line.strip() for line in f)
else:
    deleted_ids = set()

# Load your tweet archive via the tweets.js file
# Make sure it's in the same directory as this script
with open("tweets.js", "r", encoding="utf-8") as f:
    raw = f.read()

# Safely find the first occurrence of '['
start_index = raw.find("[")
if start_index == -1:
    raise ValueError("Couldn't find start of tweet array in tweets.js")

clean_json = raw[start_index:]

# Parse the JSON string into Python objects
try:
    tweets = json.loads(clean_json)
except json.JSONDecodeError as e:
    raise ValueError(f"Failed to decode JSON: {e}")

print(f"📦 Loaded {len(tweets)} tweets from archive")

# Start deleting tweets
deleted_count = 0
for entry in tweets:
    tweet = entry.get("tweet", {})
    tweet_id = tweet.get("id_str")
    created_at = tweet.get("created_at")

    # Skip tweets without valid info
    if not tweet_id or not created_at:
        continue

    # Skip tweets we've already deleted before
    if tweet_id in deleted_ids:
        print(f"⏩ Skipping already deleted tweet ID: {tweet_id}")
        continue

    # Parse the date the tweet was created
    tweet_date = datetime.strptime(created_at, "%a %b %d %H:%M:%S %z %Y").replace(tzinfo=None)

    # Only delete if within the chosen date range
    if MIN_DATE < tweet_date < MAX_DATE:
        print(f"🗑️ Deleting tweet from {tweet_date.date()} — ID: {tweet_id}")
        try:
            # Make the DELETE request using the v1.1 API
            resp = requests.post(DELETE_URL.format(tweet_id), auth=auth)
            if resp.status_code == 200:
                print("✅ Deleted")
                deleted_count += 1

                # Save to deleted list so we don’t try again later
                with open(deleted_ids_path, "a") as f:
                    f.write(tweet_id + "\n")
            else:
                print(f"⚠️ Error deleting tweet {tweet_id}: {resp.status_code} - {resp.text}")
        except (requests.exceptions.RequestException, http.client.RemoteDisconnected) as e:
            print(f"🔌 Connection error for tweet {tweet_id}: {e}. Retrying in 5 seconds...")
            time.sleep(5)
            continue
        time.sleep(2)  # Be nice to Twitter's servers, so we dont run into issues

# Final status
print(f"\n🎉 Done! Deleted {deleted_count} tweets between {MIN_DATE.date()} and {MAX_DATE.date()}.")